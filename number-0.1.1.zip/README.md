# How to use
```php
Medboubazine\NumberFormatter\NumberFormat::parse(1.2335566)->get(2); // 1.23
```